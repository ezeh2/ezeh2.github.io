﻿using System;
using UIKit;
namespace EdwardAddressList
{
	public class TableSource : UITableViewSource
	{
		private string[] TableItems;
		private string CellIdentifier = "GnabberCell";
		private MyUiTableViewController owner;

		public TableSource(string[] items, MyUiTableViewController owner)
		{
			TableItems = items;
			this.owner = owner;
		}

		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return TableItems.Length;
		}

		public override UITableViewCell GetCell(UITableView tableView, Foundation.NSIndexPath indexPath)
		{
			UITableViewCell cell = tableView.DequeueReusableCell(CellIdentifier);
			if (cell == null)
			{
				cell = new UITableViewCell(UITableViewCellStyle.Default, CellIdentifier);
			}

			string item = TableItems[indexPath.Row];
			cell.TextLabel.Text = item;

			return cell;
		}

		public override void RowSelected(UITableView tableView, Foundation.NSIndexPath indexPath)
		{
			// base.RowSelected(tableView, indexPath);

			UIAlertController ac = UIAlertController.Create("haha title", "haha message", UIAlertControllerStyle.ActionSheet);
			ac.AddAction(UIAlertAction.Create("OK", UIAlertActionStyle.Default, (obj) => {

				ac.Dispose();
			}));

			// where is owner ?
		}
	}
}
