using Foundation;
using System;
using UIKit;

namespace EdwardAddressList
{
    public partial class MenuTableViewController : UITableViewController
    {
        public MenuTableViewController (IntPtr handle) : base (handle)
        {
			
        }

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			this.Title = "Evolve 2016";
		}
    }
}