using Foundation;
using System;
using UIKit;

namespace EdwardAddressList
{
    public partial class MyUiTableViewController : UITableViewController
    {
        public MyUiTableViewController (IntPtr handle) : base (handle)
        {
        }

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			string[] x = new string[] { "Hund", "Katze", "Elefeant"};

			this.TableView.Source = new TableSource(x, this);
			// this.TableView.Source = new IndexedTableSource(x, this);
		}
    }
}