﻿using System;
using System.Collections.Generic;
using UIKit;
using System.Linq;
namespace EdwardAddressList
{
	public class IndexedTableSource: UITableViewSource
	{
		private MyUiTableViewController owner;
		private Dictionary<string, List<string>> indexedTableItems;
		private string[] keys;
		// only for caching of cells
		private string CellIdentifier = "GnabberCell";

		public IndexedTableSource(string[] items, MyUiTableViewController owner)
		{
			this.owner = owner;

			foreach (string item in items)
			{
				bool found = indexedTableItems.Keys.Any(it => it[0] == item[0]);
				if (!found) {
					indexedTableItems.Add(Convert.ToString(item[0]), new List<string>());
				}
				indexedTableItems[Convert.ToString(item[0])].Add(item);
			}

			keys = indexedTableItems.Keys.ToArray();
		}

		public override nint RowsInSection(UITableView tableview, nint section)
		{
			return indexedTableItems[keys[section]].Count;
		}

		public override nint NumberOfSections(UITableView tableView)
		{
			return keys.Length;
		}

		public override string[] SectionIndexTitles(UITableView tableView)
		{
			return indexedTableItems.Keys.ToArray();
		}

		public override UITableViewCell GetCell(UITableView tableView, Foundation.NSIndexPath indexPath)
		{
			UITableViewCell cell = tableView.DequeueReusableCell(CellIdentifier);
			if (cell == null)
			{
				cell = new UITableViewCell(UITableViewCellStyle.Default, CellIdentifier);
			}

			cell.TextLabel.Text = indexedTableItems[keys[indexPath.Section]][indexPath.Row];

			return cell;
		}
	}
}
