﻿using System;
namespace EdwardsAdressBook
{
	public class MyClass
	{
		public MyClass()
		{
		}
	}
}
