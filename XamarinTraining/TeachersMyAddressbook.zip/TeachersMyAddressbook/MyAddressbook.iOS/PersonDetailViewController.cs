using Foundation;
using System;
using UIKit;

namespace MyAddressbook.iOS
{
    public partial class PersonDetailViewController : UIViewController
    {
		private string _firstname;
		private string _lastname;

        public PersonDetailViewController (IntPtr handle) : base (handle)
        {
        }

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			LastnameTextField.EditingChanged += (sender, e) => _lastname = LastnameTextField.Text;
			FirstnameTextfield.EditingChanged += (sender, e) => _firstname = FirstnameTextfield.Text;
			SaveButton.TouchUpInside += (sender, e) => HandleStoring();
		}

		private void HandleStoring()
		{
			//Create Alert
			var okAlertController = UIAlertController.Create($"{_firstname} {_lastname}", "All your data has been saved to nowhere.. at.. all..", UIAlertControllerStyle.Alert);

			//Add Action
			okAlertController.AddAction(UIAlertAction.Create("OK", UIAlertActionStyle.Default, null));

			// Present Alert
			PresentViewController(okAlertController, true, null);
		}
    }
}