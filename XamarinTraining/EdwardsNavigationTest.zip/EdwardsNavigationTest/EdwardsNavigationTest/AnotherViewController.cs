using Foundation;
using System;
using UIKit;

namespace EdwardsNavigationTest
{
    public partial class AnotherViewController : UIViewController
    {
        public AnotherViewController (IntPtr handle) : base (handle)
        {
        }

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			BackButton.TouchUpInside += (sender, e) => { DismissViewController(true, null);};
		}
    }
}