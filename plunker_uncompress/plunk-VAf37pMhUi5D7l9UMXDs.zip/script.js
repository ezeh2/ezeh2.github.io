// Code goes here
(function() {
  
  angular.module('ngAppDemo',[])
  .controller('contr1',function($scope) {
    $scope.a=2;
  });
  
}());

